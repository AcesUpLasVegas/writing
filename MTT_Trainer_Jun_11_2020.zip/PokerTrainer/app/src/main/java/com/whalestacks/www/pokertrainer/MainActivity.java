package com.whalestacks.www.pokertrainer;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

import static java.util.Arrays.asList;

public class MainActivity extends AppCompatActivity {
    ArrayList<Integer> answers = new ArrayList<Integer>(); /* to be used later for 'River MDF Quiz' */
    String title = "River MDF";

    TextView sumTextView;
    ImageView timerImageView; /* use for time attack was timerTextView*/
    TextView questionTextView;
    TextView resultTextView;
    TextView heroTextView;
    TextView scoreTextView;
    TextView bbView;

    int score = 0;
    int numberOfQuestions = 0;
    int locationOfCorrectAnswer;

    Button button0;
    Button button1;
    Button button2;
    Button button3;
    Button playAgainButton;
    Button goButton; /* menu buttons */
    Button goButton2;
    ImageView imageViewNash;

    ConstraintLayout gameLayout;

    public void mainMenu(View view){
        goButton.setVisibility(View.VISIBLE);
        goButton2.setVisibility(View.VISIBLE);
        imageViewNash.setVisibility(View.VISIBLE);

        gameLayout.setVisibility(View.INVISIBLE);
    }
    public void playAgain(View view) {
        score = 0;
        numberOfQuestions = 0;
//        timerTextView.setText("New");
        String points = score +"/"+ numberOfQuestions;
        scoreTextView.setText(points);
        playAgainButton.setVisibility(View.INVISIBLE);
//        resultTextView.setText("");
        resultTextView.setVisibility(View.INVISIBLE);

        newQuestion();
/* ------- BEGIN CODE FOR TIMER, SHOULD BE PLUG AND PLAY USING timerTextView -----------------*/
//        new CountDownTimer(180000, 1000) {
//
//            @Override
//            public void onTick(long l) {
//                timerTextView.setText(String.valueOf(l / 1000) + "s");
//            }
//
//            @Override
//            public void onFinish() {
//                resultTextView.setText("Time Up");
//                playAgainButton.setVisibility(View.VISIBLE);
//            }
//        }.start();
/*---------- END TIMER CODE ------------- */
    }
//    public void answerList(View view) {
//        /* this method will display the question results as a list when the user presses the score box on the top right corner of the app */
//        SQLiteDatabase resultsDatabase = this.openOrCreateDatabase("Results", MODE_PRIVATE, null);
//
//        SQLiteDatabase myDatabase = this.openOrCreateDatabase("Quiz Data", MODE_PRIVATE, null);
//
//        @SuppressLint("Recycle") Cursor c = myDatabase.rawQuery("SELECT * FROM answerkey", null);
//        @SuppressLint("Recycle") Cursor d = myDatabase.rawQuery("SELECT * FROM resultskey", null);
/* old ways that broke: */
//        int positionIndex = c.getColumnIndex("position");
//        int anteIndex = c.getColumnIndex("ante");
//        int bbsIndex = c.getColumnIndex("bbs");
//        int resultsIndex = c.getColumnIndex("results");
//        int pointIndex = c.getColumnIndex("point");
//        int quizQuestionIndex = c.getColumnIndex("quizquestion");
//
//        setContentView(R.layout.answerlist);
//        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
//
//        ListView answerListView = findViewById(R.id.answerListView);
////        String x = "position " + positionIndex + "ante " + anteIndex + "bbs " + bbsIndex;
//        ArrayList<String> answers = new ArrayList<String>(asList(String.valueOf(c.getString(quizQuestionIndex))));
//        String answerDisplayText;
//
//        c.moveToFirst();
//
//        while (!c.isAfterLast()) {
//
////            answerDisplayText = "In " + String.valueOf(c.getInt(positionIndex)) + " with " + String.valueOf(c.getInt(bbsIndex)) + "bb, Ante:" + c.getString(anteIndex);
////            answers.add(answerDisplayText);
////            Log.i("position", String.valueOf(c.getInt(positionIndex)));
////            Log.i("ante", c.getString(anteIndex));
////            Log.i("bbs", String.valueOf(c.getInt(bbsIndex)));
//////            Log.i("results", c.getString(resultsIndex));
////            Log.i("point", String.valueOf(c.getIlaairvuz.comgont(pointIndex))); TYPOED
//        }
//
//        ArrayAdapter<String> huPushCallQuizAnswerList = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, answers);
//        answerListView.setAdapter(huPushCallQuizAnswerList);
//        Intent intent = new Intent(this, Main3Activity.class);
//        startActivity(intent);

//    }
    /* determines if user input equals the correct answer, and displays results accordingly, also adding to the score */
    public void chooseAnswer(View view) {
        if (Integer.toString(locationOfCorrectAnswer).equals(view.getTag().toString())) {
            resultTextView.setVisibility(View.VISIBLE);
            String ans = "Correct!";
            resultTextView.setText(ans);
            startAnimation();
//            Toast.makeText(getApplicationContext(), "CORRECT!", Toast.LENGTH_SHORT).show();
            score++;
            startAnimation2();
            startAnimation3();
    /* Records results to database for review*/
//            SQLiteDatabase resultsDatabase = this.openOrCreateDatabase("Results", MODE_PRIVATE, null);
//            resultsDatabase.execSQL("CREATE TABLE IF NOT EXISTS resultskey (results VARCHAR, point INT(1))");
//            resultsDatabase.execSQL("INSERT INTO resultskey (results, point) VALUES ('"+ans+"', 1)");
        } else {
            resultTextView.setVisibility(View.VISIBLE);
            String ans = "Wrong!";
            resultTextView.setText(ans);
//            resultTextView.animate().alpha(1f).setDuration(500);
            startAnimation();
            startAnimation2();
            startAnimation3();
//            Toast.makeText(getApplicationContext(), "WRONG!", Toast.LENGTH_SHORT).show();
            /* Records results to database for review*/
//            SQLiteDatabase resultsDatabase = this.openOrCreateDatabase("Results", MODE_PRIVATE, null);
//            resultsDatabase.execSQL("CREATE TABLE IF NOT EXISTS resultskey (results VARCHAR, point INT(1))");
//            resultsDatabase.execSQL("INSERT INTO resultskey (results, point) VALUES ('"+ans+"', 0)");
        }
        numberOfQuestions++; // adds to number of questions answered, pushes score to user display
        String fish;
        fish = score +"/"+ numberOfQuestions;
        scoreTextView.setText(fish);
// UNIMPLEMENTED CODE FOR QUIZ DATABASE:
        /* opens questions database, selects all data */
//        SQLiteDatabase myDatabase = this.openOrCreateDatabase("Quiz Data", MODE_PRIVATE, null);
//        @SuppressLint("Recycle") Cursor c = myDatabase.rawQuery("SELECT * FROM answerkey", null);
//        int positionIndex = c.getColumnIndex("position");
//        int anteIndex = c.getColumnIndex("ante");
//        int bbsIndex = c.getColumnIndex("bbs");
//
//        /*opens results database, selects all data */
//        SQLiteDatabase resultsDatabase = this.openOrCreateDatabase("Results", MODE_PRIVATE, null);
//        @SuppressLint("Recycle") Cursor d = resultsDatabase.rawQuery("SELECT * FROM resultskey", null);
//        int resultsIndex = d.getColumnIndex("results");
//        int pointIndex = d.getColumnIndex("point");
//
//        c.moveToFirst();
//
//        while (!c.isAfterLast()) {
//            Log.i("Hero in SB: ", String.valueOf(c.getInt(positionIndex)));
//            Log.i("Ante = ", c.getString(anteIndex));
//            Log.i("Stack is ", String.valueOf(c.getInt(bbsIndex) + "BBs"));
//
//            c.moveToNext();
//        }
//
//        d.moveToFirst();
//
//        while (!d.isAfterLast()) {
//            Log.i("REVIEW: ", "YOU ARE FUCKING "+ d.getString(resultsIndex));
//            Log.i("POINT = ", String.valueOf(d.getInt(pointIndex)));
//
//            d.moveToNext();
//        }
        newQuestion();
    }
    private void startAnimation() {
        // zoom animation
        Animation animation = AnimationUtils.loadAnimation(this, R.anim.anim);
        resultTextView.startAnimation(animation);
        resultTextView.setVisibility(View.INVISIBLE);
    }
//card animation method
    private void startAnimation2() {
        ImageView imageView = findViewById(R.id.cardView1);
        ImageView imageView2 = findViewById(R.id.cardView2);
        Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.anim2);
        imageView.startAnimation(animation2);
        imageView2.startAnimation(animation2);
    }
    private void startAnimation3() {
        TextView bbText = findViewById(R.id.bbView);
        TextView questText = findViewById(R.id.questionTextView);
        Animation animation2 = AnimationUtils.loadAnimation(this, R.anim.anim2);
        Animation animation4 = AnimationUtils.loadAnimation(this, R.anim.anim4);
        heroTextView.startAnimation(animation2);
        bbText.startAnimation(animation2);
        questText.startAnimation(animation4);
//        questText.setVisibility(View.INVISIBLE);
    }
/* Toggles the display back to default when quiz is restarted */
    public void start(View view) {
        goButton.setVisibility(View.INVISIBLE);
        goButton2.setVisibility(View.INVISIBLE);
        imageViewNash.setVisibility(View.INVISIBLE);
//        resultTextView.setVisibility(View.INVISIBLE);
        gameLayout.setVisibility(View.VISIBLE);
//        playAgain(findViewById(R.id.timerImageView));
        playAgain(view);
//
//        SQLiteDatabase myDatabase = this.openOrCreateDatabase("Quiz Data", MODE_PRIVATE, null);
//        myDatabase.execSQL("delete from answerkey");
//        SQLiteDatabase resultsDatabase = this.openOrCreateDatabase("Results", MODE_PRIVATE, null);
//        resultsDatabase.execSQL("delete from resultskey");
    }
/*  PROPOSED FIX FROM TEST VERSION : replace newQuestion with nashQuestion, unquote river mdf question loop*/
    public void newQuestion() {
        button2.setVisibility(View.INVISIBLE); /* 4 buttons ( used for multiple choice in River MDF Quiz ) is reduced to 2 buttons ( for True and False ) */
        button3.setVisibility(View.INVISIBLE);
//        resultTextView.animate().alpha(0f).setDuration(500);
        Random rand = new Random(); /* RNG */
        /* nash push range (grid0 - 12), and call range (matrix0 - 12) arrays; with No ante */
        int[][][] matrix = {
/* no ante push range grid */
                {       {200,   200,    200,    200,	200,	200,	200,	200,	200,	200,	200,	200,	200},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	199,	193},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	163,	135,	127},
                        {200,	200,	200,	200,	200,	200,	200,	200,    186,    147,	135,	106,	85},
                        {200,	200,	200,	200,	200,	200,	200,	200,    200,    119,	105,	77,	    65},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	144,	69, 	49, 	37},
                        {200,	180,	130,	133,	175,	200,	200,	200,	200,	188,	101,	27, 	25},
                        {200,	161,	103,	85, 	90, 	108,	147,	200,	200,	200,	139,	25, 	21},
                        {200,	151,	96, 	65, 	 57,	52, 	70,	    107,	200,	200,	163,	500 ,	20},
                        {200,	142,	89, 	60, 	41, 	35, 	30, 	26, 	24, 	200,	200,	400, 	20},
                        {200,	131,	79, 	54, 	38, 	27,	    23, 	21, 	20, 	21,	    200,	300, 	18},
                        {200,	122,	75, 	50, 	34,	    25, 	19, 	18, 	17, 	18, 	16, 	200,	17},
                        {200,	116,	70, 	46, 	29,     22, 	18,	    16,	    15,     15,     14, 	14, 	200}  },

/* no ante calling range grid */

                {	{200,  200,     200,    200,	200,	200,	200,	200,	200,	200,	200,	200,	200},
                        {200,	200,	200,	200,	200,	200,	176,	152,	143,	132,	121,	114,	107},
                        {200,	200,	200,	200,	200,	161,	130,	105,	99,	    89, 	84, 	78, 	72},
                        {200,	200,	195,	200,	180,	134,	106,	88,     70,     69, 	61, 	58, 	56},
                        {200,	200,	153,	127,	200,	115,	93, 	 74,    63,    52,  	52, 	48,	    45},
                        {200,	171,	117,	95, 	84, 	 200,	82,	   70,	   58,  	50, 	43, 	41, 	39},
                        {200,	138,	97, 	76, 	66, 	60, 	200,	65, 	56,	   48,  	41, 	36, 	35},
                        {200,	124,	80, 	64, 	55, 	50, 	47, 	200,	54,     48, 	41, 	36, 	33},
                        {200,	110,	73, 	54, 	 46,	42, 	41,	    40, 	200,	49, 	43, 	38 ,	33},
                        {200,	102,	68, 	51, 	40, 	37, 	36, 	36, 	37, 	200,	46, 	40, 	36},
                        {183,	91, 	62, 	47, 	38, 	33,	    32, 	32, 	33, 	35,	    200,	38, 	34},
                        {166,	87, 	59, 	45, 	36,	    31, 	29, 	29, 	29, 	31, 	30, 	200,	33},
                        {158,	81, 	56, 	42, 	35,     30, 	28,	    26,	    27,     28,     27, 	26, 	150}	},

                /* nash push ranges (10% ante, 0 - 12), and call ranges (10% ante 0, - 12) arrays, with a 10% ante) */

                {    {200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	200},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	200},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	200,	186,	155,	145},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	185,	154,	124,	103},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	136,	124,	89, 	74},
                        {200,	200,	200,	200,	200,	200,	200,	200,	200,	165,	80, 	60, 	47},
                        {200,	200,	149,	154,	200,	200,	200,	200,	200,	200,	118,	33, 	30},
                        {200,	183,	118,	97, 	104,	124,	168,	200,	200,	200,	159,	30, 	25},
                        {200,	174,	113,	75, 	67, 	65, 	85, 	135,	200,	200,	188,	500, 	24},
                        {200,	164,	103,	71, 	49, 	42, 	38, 	33, 	30, 	200,	200,	400, 	24},
                        {200,	150,	95, 	64, 	46, 	32, 	28, 	26, 	25, 	25, 	200,	300, 	22},
                        {200,	143,	86, 	58, 	42, 	30, 	23, 	22, 	21, 	21, 	20, 	200,	21},
                        {200,	133,	81, 	55, 	37, 	27, 	22, 	19, 	18, 	19, 	17, 	16, 	200}	},

                {  {200,    200,    200,    200, 	200,	200,	200,	200,	200,	200,	200,	200,	200},
                        {200,	200,	200,	200,	200,	200,	200,	174,	164,	151,	139,	129,	123},
                        {200,	200,	200,	200,	200,	185, 	149,	120,	114,	102,	97,  	88, 	82},
                        {200,	200,	200,	200,	200,	154,	122,	100,	81, 	79, 	70, 	66, 	64},
                        {200,	200,	178,	151, 	200,	130, 	106,	85, 	72, 	60, 	59, 	55, 	51},
                        {200,	198,	135,	109,	97, 	200,	95, 	80, 	67, 	56, 	48, 	46, 	43},
                        {200,	161,	113,	88, 	77, 	69, 	200,	74, 	64, 	55, 	47, 	40, 	39},
                        {200,	143,	92, 	74, 	65, 	57, 	54, 	200,	60, 	55, 	47, 	40, 	36},
                        {200,	128,	84, 	62, 	52, 	49, 	46, 	45, 	200,	55, 	47, 	42, 	37},
                        {200,	118,	78, 	59, 	45, 	41, 	40, 	40, 	41, 	200,	51, 	45, 	39},
                        {200,	105,	71, 	54, 	43, 	37, 	35, 	36, 	37, 	38, 	200,	42, 	38},
                        {191,	99, 	67, 	50, 	42, 	36, 	32, 	32, 	33, 	35, 	33, 	200,	36},
                        {184,	94, 	64, 	48, 	39, 	34, 	31, 	29, 	30, 	31, 	30, 	29, 	169}	}	};

        int stack = rand.nextInt(20) + 1; /* effective stack (randomly generated) expressed in big blinds (bb) */

        String ante;
//        String firstCard;
//        String secondCard;
//        String style = "unknown"; /* style is declared, needs a place holder word before getting defined later to determine suited or pocket pair. unknown used as glitch indicator */
//        title = "BETA"; /* at top of screen */
//        sumTextView.setText(title);
//        int anteRand = rand.nextInt(9); /* RNG to determine push no ante, call no ante, push 10% ante, call 10% ante ( see if loop below) */
        int mode = rand.nextInt(4); /* RNG to determine which question to display: push or call */

        if (mode < 2) {
            ante = "No";
            Log.i("Ante:", "none; return val=" + mode);
        } else {
            ante = "10%";
            Log.i("Ante:", "10%; return val=" + mode);
        }
/* changed this sequence due to bug in matrix from ante generation; replaced 'anterand' universally with variablke 'mode'*/
//        if (anteRand < 5) {
//            ante = "No";
//            Log.i("Ante:", "none; return val=" + anteRand);
//        } else {
//            ante = "10%";
//            Log.i("Ante:", "10%; return val=" + anteRand);
//        }
// Builds standard deck of 52 cards, with strings in the array corresponding to filenames of card .PNGs
        String[] deck = new String[]
                {"card_0_c", "card_1_c", "card_2_c", "card_3_c", "card_4_c", "card_5_c", "card_6_c", "card_7_c", "card_8_c", "card_9_c", "card_10_c", "card_11_c", "card_12_c",
                        "card_0_d", "card_1_d", "card_2_d", "card_3_d", "card_4_d", "card_5_d", "card_6_d", "card_7_d", "card_8_d", "card_9_d", "card_10_d", "card_11_d", "card_12_d",
                        "card_0_h", "card_1_h", "card_2_h", "card_3_h", "card_4_h", "card_5_h", "card_6_h", "card_7_h", "card_8_h", "card_9_h", "card_10_h", "card_11_h", "card_12_h",
                        "card_0_s", "card_1_s", "card_2_s", "card_3_s", "card_4_s", "card_5_s", "card_6_s", "card_7_s", "card_8_s", "card_9_s", "card_10_s", "card_11_s", "card_12_s"};

        int x = rand.nextInt(52);
        int y = rand.nextInt(51);
//        int mode = rand.nextInt(2); /* RNG to determine which question to display: push or call */
        for (int i = 0; i < deck.length; i++)
            System.out.println("Element at index " + i +
                    " : " + deck[i]);

        String[] deck2 = new String[deck.length - 1];

        ArrayList<String> cards = new ArrayList<>(asList(deck));
            cards.remove(x);
            cards.toArray(deck2);

        for (int i = 0; i < deck2.length; i++)
            System.out.println("Element at index " + i +
                    " : " + deck2[i]);

        String holeCard1 = deck[x];
        String holeCard2 = deck2[y];

        String[] arrOfHoleCard1 = holeCard1.split("_",0);
        String[] arrOfHoleCard2 = holeCard2.split("_",0);

        int rank1 = Integer.parseInt(String.valueOf(arrOfHoleCard1[1]));
        int rank2 = Integer.parseInt(String.valueOf(arrOfHoleCard2[1]));
        String suit1 = arrOfHoleCard1[2];
        String suit2 = arrOfHoleCard2[2];

        Log.i("1st ranking number ", String.valueOf(x));
        Log.i("2nd ranking number is ", String.valueOf(y));
        Log.i("FIRST card is ", deck[x] + " suit is " + suit1 + ", rank is " + rank1 + "  ");
        Log.i("SECOND card is ", deck2[y] + " suit is " + suit2 + ", rank is " + rank2 + "  ");
        /* block of code used to figure out if a hand is suited or unsuited (pocket pairs count as unsuited) by using the filename string extraction of the suit (s, h ,d , c)*/
        String handType;
        int chartReader = 10;
        if (suit1.equals(suit2)) {
             handType = "Suited";
//            Log.i("HAND is ", " " + handType);
//        }
//        if (rank1 == rank2) {
//             handType = "Pocket Pair";
////            Log.i("HAND is ", " " + handType);
        } else {
             handType = "Unsuited";
//            Log.i("HAND is ", " " + handType);
        }
        if (handType.equals("Suited")) {
            chartReader = matrix[mode][Math.min(rank1,rank2)][Math.max(rank1,rank2)];
        } else {
            chartReader = matrix[mode][Math.max(rank1,rank2)][Math.min(rank1,rank2)];
        }

        double handValue =  Math.round((float) chartReader / 10) ; /* this will be the nash answer expressed in big blinds ( placeholder is needed, true value will be defined later. 0.5 can be used as a glitch indicator */

        Log.i("HANDVALUE is ", String.valueOf(handValue));
        Log.i("Mode is ", String.valueOf(mode));

        String valueTown = "0_push_" + rank1;
//        Log.i("HAND VALUE ", " " + valueTown);

        ImageView imageView = findViewById(R.id.cardView1);
        Context context = imageView.getContext();
        int id = context.getResources().getIdentifier(holeCard1, "drawable", context.getPackageName());
        imageView.setImageResource(id);
        ImageView imageView2 = findViewById(R.id.cardView2);
        Context context2 = imageView2.getContext();
        int id2 = context2.getResources().getIdentifier(holeCard2, "drawable", context.getPackageName());
        imageView2.setImageResource(id2);

        if (handValue == 50 && stack > 7.1) {
            handValue = 7;
        } else if (handValue == 50 && stack < 5.1 && stack > 2.3) {
            handValue = 10;
        } else if (handValue == 50 && stack > 5.1 && stack < 7.1) {
            handValue = 10;
        } else if (handValue == 50 && stack < 2.3) {
            handValue = 2;
        }
        if (handValue == 40 && stack > 12.9) {
            handValue = 13;
        } else if (handValue == 40 && stack < 3.8 && stack > 2.4) {
            handValue = 15;
        } else if (handValue == 40 && stack > 3.8 && stack < 12.9) {
            handValue = 15;
        } else if (handValue == 40 && stack < 2.4) {
            handValue = 2;
        }
        if (handValue == 30 && stack > 10) {
            handValue = 10;
        } else if (handValue == 30 && stack < 4.9 && stack > 2.2) {
            handValue = 15;
        } else if (handValue == 30 && stack > 4.9 && stack < 10) {
            handValue = 15;
        } else if (handValue == 50 && stack < 2.2) {
            handValue = 2;
        }
//
//        if (suit1.equals(suit2)) {
//            String handType = "Suited Cards";
////            Log.i("HAND is ", " " + handType);
//        }
//        if (rank1 == rank2) {
//            String handType = "Pocket Pair";
////            Log.i("HAND is ", " " + handType);
//        }
        String stk = stack + " bb";
        String ant = " " + ante + " ante ";
        bbView.setText(stk); /* displays effective stack next to player's hole card display */
        heroTextView.setText(ant);
/* determines which question type to display ( 'call' or 'jam') , and changes the button text accordingly as well */
        if ( mode == 3 || mode == 1 ) {
            questionTextView.setText("Villain in SB");
            button0.setText("Call");
        } else {
            questionTextView.setText("Hero in SB");
            button0.setText("Push");
        }
/* determines the correct answer using basic true/false logic . jumps to chooseAnswer on button click */
        if (stack > handValue) {
            locationOfCorrectAnswer = 1;/*fold*/
        } else {
            locationOfCorrectAnswer = 0;
        }
// UNIMPLEMENTED CODE FOR QUIZ DATABASE:
//        String quizQuestionString = "Mode is "+mode+" ante is (TBD) stack is "+stack;
////        Log.i("handValue", String.valueOf(handValue)); /* puts the correct answer to the logs for debugging purposes */
///* Creates a datatbase to store the questions for the user to review later if desired.*/
//        SQLiteDatabase myDatabase = this.openOrCreateDatabase("Quiz Data", MODE_PRIVATE, null);
//        myDatabase.execSQL("CREATE TABLE IF NOT EXISTS answerkey (quizquestion VARCHAR)");
//        myDatabase.execSQL("INSERT INTO answerkey (quizquestion) VALUES ('"+quizQuestionString+"')");
        /* old method shown below: we consolodated everything to one row for easier output*/
//        myDatabase.execSQL("CREATE TABLE IF NOT EXISTS answerkey (position INT(1), ante VARCHAR, bbs INT(2), results VARCHAR, point INT(1))");
//        myDatabase.execSQL("INSERT INTO answerkey (position, ante, bbs) VALUES ("+mode+", '"+ante+"', "+stack+" )");
//        @SuppressLint("Recycle") Cursor c = myDatabase.rawQuery("SELECT * FROM answerkey", null);
//
//        int positionIndex = c.getColumnIndex("position");
//        int anteIndex = c.getColumnIndex("ante");
//        int bbsIndex = c.getColumnIndex("bbs");
       // int resultsIndex = c.getColumnIndex("results");
       // int pointIndex = c.getColumnIndex("point");
//        c.moveToFirst();
//
//        while (!c.isAfterLast()) {
//            Log.i("position", String.valueOf(c.getInt(positionIndex)));
//            Log.i("ante",c.getString(anteIndex));
//            Log.i("bbs", String.valueOf(c.getInt(bbsIndex)));
//           // Log.i("results", c.getString(resultsIndex));
//           // Log.i("point", String.valueOf(c.getInt(pointIndex)));
//
//            c.moveToNext();
//        }
    }
/*----------- BEGIN SECTION OF CODE FOR 'RIVER MDF QUIZ' (TO BE ADDED IN LATER AS AN OPTION
        public void newQuestion() {
        Random rand = new Random();
        int[] mix = {40,38,33,30,25,20,17,14};
        int x = rand.nextInt(8);
        int pot = rand.nextInt(100) * 10;
        double size = 1;
        int percentage = 1;
        double size0 = pot * 2;
        double size1 = pot * 1.5;
        double size2 = pot * 1;
        double size3 = pot * 0.75;
        double size4 = pot * 0.5;
        double size5 = pot * 0.33;
        double size6 = pot * 0.25;
        double size7 = pot * 0.20;
        if (x == 0) {
            size = size0;
            percentage = 40;
        } else {
            if (x == 1) {
                size = size1;
                percentage = 37;
            } else {
                    if (x == 3) {
                        size = size3;
                        percentage = 30;
                    } else {
                        if (x == 4) {
                            size = size4;
                            percentage = 25;
                        } else {
                            if (x == 5) {
                                size = size5;
                                percentage = 20;
                            } else {
                                if (x == 6) {
                                    size = size6;
                                    percentage = 17;
                                } else {
                                    if (x == 7) {
                                        size = size7;
                                        percentage = 14;
                                    } else {
                                        size = size2;
                                        percentage = 33;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        sumTextView.setText(title);
        questionTextView.setText("Villain bets " + Math.round(size)+ " into " + pot + " on the river. How often can we profitably call? ");
        locationOfCorrectAnswer = rand.nextInt(4);
        answers.clear();
        for (int i=0; i<4; i++) {
            if (i == locationOfCorrectAnswer) {
                answers.add(percentage);
            } else {
                int wrong= new Random().nextInt(8);
                int wrongAnswer = mix[wrong];
                while (wrongAnswer == percentage) {
                    wrongAnswer = mix[wrong];
                }
                answers.add(wrongAnswer);
            }
        }
        button0.setText(Integer.toString(answers.get(0)) + "%");
        button1.setText(Integer.toString(answers.get(1)) + "%");
        button2.setText(Integer.toString(answers.get(2)) + "%");
        button3.setText(Integer.toString(answers.get(3)) + "%");
    }
---------END SECTION OF 'RIVER MDF QUIZ' ----------------*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
//  button UI declarations
        goButton2 = (Button) findViewById(R.id.goButton2);
//        sumTextView = findViewById(R.id.sumTextView);
        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        bbView = findViewById(R.id.bbView);
        resultTextView = findViewById(R.id.resultTextView);
        heroTextView = findViewById(R.id.heroTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
//        timerTextView = findViewById(R.id.timerTextView);
        questionTextView = findViewById(R.id.questionTextView);
        playAgainButton = findViewById(R.id.playAgainButton);
        goButton = findViewById(R.id.goButton);
        goButton2 = findViewById(R.id.goButton2);
        imageViewNash = findViewById(R.id.imageViewNash);
        gameLayout = findViewById(R.id.gameLayout);
// Animation on title screen builds
        Animation fadeIn = AnimationUtils.loadAnimation(this, R.anim.anim5);
        Animation logoAnim = AnimationUtils.loadAnimation(this, R.anim.anim3);
        imageViewNash.startAnimation(logoAnim);
        goButton.startAnimation(fadeIn);
        goButton2.startAnimation(fadeIn);
/* toggles visibility from start screen to game screen */
        goButton.setVisibility(View.VISIBLE);
        goButton2.setVisibility(View.VISIBLE);
        imageViewNash.setVisibility(View.VISIBLE);
        gameLayout.setVisibility(View.INVISIBLE);
        goButton2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                tableView();
            }

        });

    }

    public void tableView() {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }
}

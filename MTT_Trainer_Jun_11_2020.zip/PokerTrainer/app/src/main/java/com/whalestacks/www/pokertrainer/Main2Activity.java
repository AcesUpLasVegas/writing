package com.whalestacks.www.pokertrainer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Random;

public class Main2Activity extends AppCompatActivity {
    ImageView menuButton;

    String message;
    String imageName;

    int position;
    int anteKey;

    Random rand = new Random();

    RadioGroup radioGroup;
    RadioButton radioButton;
      /* Updated: 4-13-20 ,  By: Jeremiah Moore ,
    replaced 1200+ lines of code using if else statements to lean out the program, improve performance and radio button id bug issues. This was done prior in MainActivity as many lines
    of code were transformed into a 3D array. the description of the array is below
    --end     */
    int[][][] fullRingShoveMatrix =
            /* 3d array storing the data: anteType[3], stackSize[15], position[10]. Using a int array for first test, if this does not work try using String or Arraylist,. */
            /*        SB   UTG    UTG1   EP    MP   LJ   HJ    CO    BTN   BB(call)    */
            {{
                    {10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 9190, 10000},  // 1 bb
                    {10000, 9000, 9000, 9000, 9000, 9000, 9000, 8430, 7220, 10000}, // 2
                    {9550, 6470, 6470, 6440, 6440, 6440, 6230, 6140, 6260, 10000},  // 3
                    {8790, 4060, 4090, 4180, 4240, 4390, 4690, 5110, 5720, 9250},   // 4
                    {8310, 2350, 2640, 3060, 3180, 3700, 4120, 4690, 5480, 7920},   // 5 bb
                    {8190, 1990, 2310, 2520, 2940, 3330, 3790, 4390, 5290, 7130},   // 6
                    {7920, 1840, 2040, 2340, 2730, 3060, 3420, 4150, 5110, 6170},   // 7
                    {7620, 1690, 1920, 2130, 2490, 2940, 3360, 3970, 5050, 5600},   // 8
                    {7380, 1570, 1720, 2040, 2250, 2820, 3210, 3760, 4750, 5080},   // 9
                    {7320, 1460, 1660, 1960, 2190, 2520, 3150, 3570, 4540, 4750},   // 10 bb
                    {7100, 1300, 1540, 1720, 2070, 2400, 2940, 3450, 4420, 4390},   //  11
                    {6920, 1300, 1460, 1570, 2010, 2430, 2820, 3330, 4180, 4180},   // 12
                    {6710, 1176, 1370, 1460, 1750, 2070, 2640, 3300, 4090, 3970},   // 13
                    {6500, 1040, 1300, 1460, 1690, 2070, 2580, 3270, 3850, 3790},   // 14
                    {6380, 950, 1210, 1370, 1630, 2010, 2400, 3090, 3790, 3570}},   // 15 bb
             /*        SB   UTG    UTG1   EP    MP   LJ   HJ    CO    BTN   BB(call)    */
                    {{10000, 10000, 10000, 10000, 10000, 10000, 10000, 10000, 8790, 10000},// 1 bb
                    {10000, 8550, 8550, 8550, 8550, 8550, 8460, 8070, 6800, 10000}, // 2
                    {9250, 5440, 5570, 5440, 5410, 5570, 5690, 5930, 6020, 10000},  // 3
                    {3150, 3060, 2790, 8690, 2850, 2940, 3030, 3060, 3090, 8914},   // 4
                    {8190, 2170, 2340, 2700, 3060, 3300, 3910, 4360, 5350, 7466},   // 5 bb
                    {8010, 1870, 2130, 2460, 2820, 3240, 3600, 4180, 5080, 6712},   // 6
                    {7620, 1690, 1870, 2130, 2490, 3030, 3330, 4060, 4900, 5686},   // 7
                    {7440, 1520, 1750, 1950, 2340, 2730, 3210, 3670, 4630, 5264},   // 8
                    {7220, 1460, 1570, 1870, 2190, 2520, 3060, 3540, 4510, 4691},    // 9
                    {7100, 1340, 1540, 1720, 2040, 2400, 3030, 3420, 4300, 4329},    // 10 bb
                    {6830, 1270, 1460, 1660, 1780, 2250, 2730, 3300, 4060, 4057},  //  11
                    {6620, 1180, 1270, 1510, 1780, 2100, 2610, 3270, 4060, 3725},    // 12
                    {6470, 1040, 1270, 1460, 1660, 2040, 2490, 3180, 3760, 3514},    // 13
                    {6290, 950, 1150, 1370, 1600, 1830, 2310, 2970, 3730, 3394},     // 14
                    {6050, 950, 1040, 1270, 1510, 1780, 2250, 2970, 3630, 3183}},    // 15 bb
             /*        SB   UTG    UTG1   EP    MP   LJ   HJ    CO    BTN   BB(call)    */
                    {{10000, 9280, 9280, 9280, 9280, 9280, 9190, 7130, 4230, 10000}, // 1 bb
                     {9550, 4240, 4240, 4240, 4120, 4090, 4210, 4120, 4280, 10000},  // 2
                     {8070, 1860, 2100, 2220, 2460, 2900, 3240, 3680, 4210, 9820},   // 3
                     {7560, 1580, 1810, 2020, 2400, 2700, 3120, 3600, 4210, 8340},   // 4
                     {7290, 1430, 1570, 1810, 2010, 2430, 2940, 3300, 4090, 6770},   // 5 bb
                     {6680, 1370, 1430, 1600, 1920, 2220, 2700, 3210, 3850, 5840},   // 6
                     {6770, 1180, 1270, 1460, 1720, 2010, 2460, 3090, 3670, 5130},   // 7
                     {6170, 1180, 1040, 1430, 1540, 1920, 2220, 2900, 3450, 4660},   // 8
                     {5870, 940, 1040, 1210, 1430, 1690, 2070, 2790, 3300, 4200},    // 9
                     {5600, 900, 940, 1040, 1340, 1630, 2010, 2580, 3240, 3940},     // 10 bb
                     {5410, 750, 860, 1040, 1210, 1460, 1870, 2310, 3180, 3635},    //  11
                     {5260, 570, 750, 940, 1090, 1370, 1660, 2310, 3210, 3424},      // 12
                     {5200, 570, 720, 860, 1040, 1270, 1600, 2310, 3030, 3180},      // 13
                     {4900, 480, 680, 720, 950, 1210, 1510, 2010, 2850, 3000},       // 14
                     {4690, 480, 480, 680, 900, 1000, 1370, 1860, 2760, 2881}}};     // 15 bb
    /* anteKey: 0 = "12.5%", 1 = "10%", 2 = "None"   ; stackSize = [ante][numberOfBigBlindsEditText - 1]  (stackSize will be r4resented as the first 8lumn of the
    chart, like firstCard in quiz model	; position = [ante][stack][position] (position data will be the shove value in percentage of hands, to be called
    later in the program and 8rrelate to chart .png to display. Below is the 8de from the quiz activity to 8nvert array value into and id that can be
    passed to an imageView to display proper shove range matrix . png
    ***Also, there are no current BB ranges (we will put calling ranges to SB shove later). 9 is just a placeholder or error return (random button can still show 9
    */
//    public void checkButton(View v){
//        int radioId = radioGroup.getCheckedRadioButtonId();
//        radioButton = findViewById(radioId);
    public void sbRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 0;
        String clickedPosition = "SB";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);

        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb " + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void bbRanges(View view) {
//        ImageView rangeMatrixImageView = findViewById(R.id.rangeMatrixImageView);
//        TextView stackDetailsTextView = findViewById(R.id.stackDetailsTextView);
//        message = "There are no shove ranges for BB";
//        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
//        stackDetailsTextView.setVisibility(View.INVISIBLE);
//        rangeMatrixImageView.setVisibility(View.INVISIBLE);
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 9;
        String clickedPosition = "BB";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage + "_call";
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);

        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText("Call SB Open Shove from" + System.getProperty("line.separator") + clickedPosition + " with " + stackSize + "bb, " + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void utgRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 1;
        String clickedPosition = "UTG";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void utg1Ranges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 2;
        String clickedPosition = "UTG1";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void epRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 3;
        String clickedPosition = "EP";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void mpRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 4;
        String clickedPosition = "MP";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void ljRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 5;
        String clickedPosition = "LJ";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void hjRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 6;
        String clickedPosition = "HJ";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void coRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 7;
        String clickedPosition = "CO";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }
        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText( clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void btnRanges(View view) {
        /*sets table position: 0 = sb ; replaced string with int for easier access to fullRingShoveMatrix */
        position = 8;
        String clickedPosition = "BTN";
        /* Gets StackSize :  converts numberOfBigBlindsEditText to a string, and then converts the string to an int (it was breaking before, solution found on stack oflow*/
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        String nutrag = numberOfBigBlindsEditText.getText().toString();

        if (nutrag.isEmpty() ) {
            message = "Please enter a Valid Stack Size";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            return;
        }

        int stackSize = Integer.parseInt(nutrag);

        if (stackSize < 1 || stackSize > 15) {
            message = "BB value must be 1 - 15";
            Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            Log.i("HEY", "inValid Stack");
            return;
        }
        /* Gets ante value from radio button*/
        radioGroup = findViewById(R.id.radioGroup);
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        String ante = String.valueOf(radioButton.getText());
        /* Determines value of ante, converts to antekey int to look up in fullRingshoveMatrix */
        if (ante.equals("12.5%")) anteKey = 0;
        if (ante.equals("10%")) anteKey = 1;
        if (ante.equals("None")) anteKey = 2;
        /* Gets the shove range based on data provided by user */
        int rangePercentage = fullRingShoveMatrix[anteKey][stackSize - 1][position];
        /* Creates an id called imageName which corresponds to the correct .png image of hand range to display */
        imageName = "range" + rangePercentage;
        /* This sets the card view from the rng data */
        ImageView rangeView = findViewById(R.id.rangeMatrixImageView);
        Context context = rangeView.getContext();
        int id = context.getResources().getIdentifier(imageName, "drawable", context.getPackageName());
        rangeView.setImageResource(id);
        /* Logging for debug purposes only*/
        Log.i("YOOO", ante + "  " + imageName + "  " + anteKey + "  " + radioId + " " + rangePercentage);
        /* This toggles visibility of range matrix and randomize button*/
        rangeView.setVisibility(View.VISIBLE);
        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.INVISIBLE);
        TextView displayMessage = findViewById(R.id.stackDetailsTextView);
        displayMessage.setVisibility(View.VISIBLE);
        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.VISIBLE);

        displayMessage.setText(clickedPosition + " with " + stackSize + "bb" + System.getProperty("line.separator")
                + "Ante: " + ante);
        // Animation of rangeView (fade in)
        Animation animation5 = AnimationUtils.loadAnimation(this, R.anim.anim5);
        rangeView.startAnimation(animation5);
        displayMessage.startAnimation(animation5);
        blackScreen.startAnimation(animation5);
    }
    public void randomSpot(View view) throws NoSuchMethodException {
        int[] seatPosition = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        position = seatPosition[rand.nextInt(9)];
        Log.i("random spot", String.valueOf(position));
        int randomStackSize = rand.nextInt(14) + 1;
        SeekBar bigBlindSeekBar = (SeekBar) findViewById(R.id.bigBlindSeekBar);
// update seekbar value
        bigBlindSeekBar.setProgress(randomStackSize - 1);
// update bb display
        TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
        numberOfBigBlindsEditText.setText(String.valueOf(randomStackSize));

        switch (position) {
            case 0:
                sbRanges(view);
                break;
            case 1:
                bbRanges(view);
                break;
            case 2:
                utgRanges(view);
                break;
            case 3:
                utg1Ranges(view);
                break;
            case 4:
                epRanges(view);
                break;
            case 5:
                mpRanges(view);
                break;
            case 6:
                ljRanges(view);
                break;
            case 7:
                hjRanges(view);
                break;
            case 8:
                coRanges(view);
                break;
            case 9:
                btnRanges(view);
            default:
                break;
        }
//        if ( position == 0) {
//            sbRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 1) {
//            bbRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 2) {
//            utgRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 3) {
//            utg1Ranges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 4) {
//            epRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 5) {
//            mpRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 6) {
//            ljRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 7) {
//            hjRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 8) {
//            coRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
//        if ( position == 9) {
//            btnRanges(view);
//            bigBlindSeekBar.setProgress(randomStackSize - 1);
//        }
    }
    public void clearRange(View view) {
        ImageView rangeMatrixImageView = findViewById(R.id.rangeMatrixImageView);
        rangeMatrixImageView.setVisibility(View.INVISIBLE);

        ImageView blackScreen = findViewById(R.id.blackScreen);
        blackScreen.setVisibility(View.INVISIBLE);

        TextView stackDetailsTextView = findViewById(R.id.stackDetailsTextView);
        stackDetailsTextView.setVisibility(View.INVISIBLE);

        Button randoButton = findViewById(R.id.randomizeButton);
        randoButton.setVisibility(View.VISIBLE);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
        final TextView numberOfBigBlindsEditText = findViewById(R.id.textView);
        final SeekBar bigBlindSeekBar = (SeekBar) findViewById(R.id.bigBlindSeekBar);

        bigBlindSeekBar.setMax(14);
        bigBlindSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onProgressChanged(SeekBar seekBar, int i, boolean fromUser)
            {
            if (!String.valueOf(bigBlindSeekBar.getProgress()).isEmpty()) {
                   Log.i("seekbar changed", Integer.toString(i));
                   TextView numberOfBigBlindsEditText = findViewById(R.id.numberOfBigBlindsEditText);
                   numberOfBigBlindsEditText.setText(String.valueOf(i+1));
            } else {
                   numberOfBigBlindsEditText.setText("1");
                   bigBlindSeekBar.setProgress(1);
            }
        }
    });
        menuButton = findViewById(R.id.menuButton);
        menuButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
